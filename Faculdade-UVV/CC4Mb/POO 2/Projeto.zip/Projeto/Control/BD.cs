﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto.Control
{
    internal class BD
    {
        public static List<Amigo> lista = new();

        public static void salvarAmigo(Amigo amigo) =>lista.Add(amigo);
    }
}
